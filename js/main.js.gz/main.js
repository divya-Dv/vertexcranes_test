!(function (a) {
  "use strict";
  var e = a("nav").outerHeight();
  if (
    (a(".navbar-toggler").on("click", function () {
      a("#mainNav").hasClass("navbar-reduce") ||
        a("#mainNav").addClass("navbar-reduce");
    }),
    a(window).on("load", function () {
      a("#preloader").length &&
        a("#preloader")
          .delay(100)
          .fadeOut("slow", function () {
            a(this).remove();
          });
    }),
    a(window).scroll(function () {
      a(this).scrollTop() > 100
        ? a(".back-to-top").fadeIn("slow")
        : a(".back-to-top").fadeOut("slow");
    }),
    a(".back-to-top").click(function () {
      return (
        a("html, body").animate({ scrollTop: 0 }, 1500, "easeInOutExpo"), !1
      );
    }),
    a(".scrolltop-mf").on("click", function () {
      a("html, body").animate({ scrollTop: 0 }, 1e3);
    }),
    a(".counter").counterUp({ delay: 15, time: 2e3 }),
    a('a.js-scroll[href*="#"]:not([href="#"])').on("click", function () {
      if (
        location.pathname.replace(/^\//, "") ==
          this.pathname.replace(/^\//, "") &&
        location.hostname == this.hostname
      ) {
        var o = a(this.hash);
        if ((o = o.length ? o : a("[name=" + this.hash.slice(1) + "]")).length)
          return (
            a("html, body").animate(
              { scrollTop: o.offset().top - e + 5 },
              1e3,
              "easeInOutExpo"
            ),
            !1
          );
      }
    }),
    a(".js-scroll").on("click", function () {
      a(".navbar-collapse").collapse("hide");
    }),
    a("body").scrollspy({ target: "#mainNav", offset: e }),
    a(window).trigger("scroll"),
    a(window).on("scroll", function () {
      a(window).scrollTop() > 50
        ? (a(".navbar-expand-md").addClass("navbar-reduce"),
          a(".navbar-expand-md").removeClass("navbar-trans"))
        : (a(".navbar-expand-md").addClass("navbar-trans"),
          a(".navbar-expand-md").removeClass("navbar-reduce")),
        a(window).scrollTop() > 1200
          ? a(".scrolltop-mf").fadeIn(1e3, "easeInOutExpo")
          : a(".scrolltop-mf").fadeOut(1e3, "easeInOutExpo");
    }),
    1 == a(".text-slider").length)
  ) {
    var o = a(".text-slider-items").text();
    new Typed(".text-slider", {
      strings: o.split(","),
      typeSpeed: 80,
      loop: !0,
      backDelay: 1100,
      backSpeed: 30,
    });
  }
  a("#testimonial-mf").owlCarousel({
    margin: 20,
    autoplay: !0,
    autoplayTimeout: 4e3,
    autoplayHoverPause: !0,
    responsive: { 0: { items: 1 } },
  });
})(jQuery);
